//Array (arreglo) para las imagenes, aquí van a poner las imagenes//
// de cada uno (ES INDIVIDUAL) //

const imagenes = ["https://plus.unsplash.com/premium_photo-1672423156257-9a2bc5e1f480?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGZpbmFuemFzfGVufDB8fDB8fHww","https://images.unsplash.com/photo-1579532537598-459ecdaf39cc?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTN8fGZpbmFuemFzfGVufDB8fDB8fHww", "https://images.unsplash.com/photo-1508385082359-f38ae991e8f2?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTd8fGZpbmFuemFzfGVufDB8fDB8fHww", "https://images.unsplash.com/photo-1615469309489-0a464a9925cb?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8cHdjfGVufDB8fDB8fHww", "https://images.unsplash.com/photo-1661178009605-8bfb6fb85607?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8anAlMjBtb3JnYW58ZW58MHx8MHx8fDA%3D"];

// Selección de elementos//

const boton = document.getElementById("btn-cambiar");

const imagenCard = document.getElementById("card-img");

const textoCard = document.getElementById("card-text");

//contador de las imágenes//

let indice = 0;

// Evento del click //

boton.addEventListener("click", ()=> 
                      {
  // lo siguiente sirve para que la foto avance //
  indice++;
  
  //el siguiente if es para cuando llegue el final, se regrese al inicio//
  
  if(indice >= imagenes.length){
    indice = 0; }
 // cambiar la imagen y el texto de las card //
    imagenCard.src = imagenes[indice];
    textoCard.textContent = `Mostrando imagen ${indice + 1} de ${imagenes.length}`;
}
                      )