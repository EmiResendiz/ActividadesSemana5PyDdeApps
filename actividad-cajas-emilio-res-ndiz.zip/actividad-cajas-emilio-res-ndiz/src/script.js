//desafio 1 getElementById//

document.getElementById("btn-titulo").addEventListener("click",()=>
                                         {
  const titulo = document.getElementById("titulo");
  titulo.textContent = "¡El click funciona!";
}             
                                                      );

//desafio 2 getElementByClassName//

document.getElementById("btn-cajas").addEventListener("click",()=> {
  const cajas = document.getElementsByClassName("caja");
  
  for (let i = 0; i < cajas.length; i++) {
      cajas[i].style.backgroundColor="green";  
    }
});

//desafio 3 getElementByClassName//

document.getElementById("btn-primera").addEventListener("click",()=> {
  const primeraCaja = document.querySelector(".caja");
  
  primeraCaja.style.backgroundColor = "lightgreen";
}
                                                       );

//desafio 4 querySelectorAll() cambiarle el borde a todas las cajas 2px//

document.getElementById("btn-bordes").addEventListener("click",()=>                                                  {
  const cajas =
  document.querySelectorAll(".caja");
  cajas.forEach(caja =>
               {
    caja.style.border = "2px solid red";
  });
}
                                                       );